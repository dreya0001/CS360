package com.example.myapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    DatabaseHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen); // Your login screen layout

        database = new DatabaseHelper(this);

        Button loginButton = findViewById(R.id.btn_login);
        Button createAccountButton = findViewById(R.id.btn_create_account);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText usernameField = findViewById(R.id.username);
                EditText passwordField = findViewById(R.id.password);
                String username = usernameField.getText().toString();
                String password = passwordField.getText().toString();
                loginUser(username, password);
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText usernameField = findViewById(R.id.username);
                EditText passwordField = findViewById(R.id.password);
                createAccount(usernameField.getText().toString(), passwordField.getText().toString());
            }
        });
    }

    private void loginUser(String username, String password) {
        Cursor cursor = database.getUser(username, password);
        if (cursor.moveToFirst()) {
            // Successful login
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            // Navigate to the DataDisplayActivity (not shown here)
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    private void createAccount(String username, String password) {
        if (database.addUser(username, password)) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show();
        }
    }
}