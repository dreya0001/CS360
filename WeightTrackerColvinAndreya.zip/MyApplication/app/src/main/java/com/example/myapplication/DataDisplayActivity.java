package com.example.myapplication;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {
    DatabaseHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display); // Your data display layout

        database = new DatabaseHelper(this);
        GridLayout dataGrid = findViewById(R.id.data_grid);

        displayData(dataGrid);

        Button addDataButton = findViewById(R.id.btn_add_data);
        addDataButton.setOnClickListener(v -> {
            // Logic to add new entry (not implemented in this snippet)
        });
    }

    private void displayData(GridLayout dataGrid) {
        Cursor cursor = database.getAllData(); // Method to fetch all data from the database

        // Clear previous views if any
        dataGrid.removeAllViews();

        // Adding headers to the grid
        dataGrid.addView(createTextView("Date"));
        dataGrid.addView(createTextView("Weight"));
        dataGrid.addView(createTextView("Actions"));

        while (cursor.moveToNext()) {
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String weight = cursor.getString(cursor.getColumnIndex("weight"));

            dataGrid.addView(createTextView(date));
            dataGrid.addView(createTextView(weight));
            dataGrid.addView(createActionButton(date)); // A button to delete the entry
        }
        cursor.close();
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        return textView;
    }

    private Button createActionButton(String date) {
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(v -> {
            // Logic to delete the entry (not implemented in this snippet)
        });
        return deleteButton;
    }
}